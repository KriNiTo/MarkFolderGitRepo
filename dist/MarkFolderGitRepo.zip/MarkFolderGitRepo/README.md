MarkFolderGitRepo
=================

Mark Folders in Windows Explorer with a Git-Icon to visualize that a Git-Repo exists.

What it looks like in Explorer: 
https://github.com/KriNiTo/MarkFolderGitRepo/blob/master/images/Folder.png

You can easily Mark/Unmark via SendTo Menu:
https://github.com/KriNiTo/MarkFolderGitRepo/blob/master/images/SendTo.png

Setup:
------
- Download .zip file from .\dist
- Extract to %Userprofile%\Scripts (e.g.: C:\Users\MyUserName\Scripts)
- Execute "MarkFolderGitRepo\Install_in_SendTo-Folder.bat"
- Now you can Mark/Unmark a Folder via SendTo Menu-entry (Notice: It could take 5 minutes until the explorer recognizes the new setting)

Have fun!
